# Welcome to my notes!
Feel free to browse for anything you like!  

if you have any topics you'd like me to cover, please open an issue with the `new` tag  

if you find an error, please open an issue with the `error` tag


# Notes
1. There are other classes who's notes I can't release because I was dumb and stored them locally on a PC that decided to die
2. Homeworks/labs ***MAY*** be uploaded after graduation